import time
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User, Group, auth
from django.contrib import messages
import stripe
from Bertv3.settings import STRIPE_PUBLISHABLE_KEY,STRIPE_SECRET_KEY
from .models import *
from django.core.mail import send_mail
from django.core.mail import EmailMessage
from Bertv3.settings import *


MY_DOMAIN = 'http://127.0.0.1:8000/'
stripe_public_key = STRIPE_PUBLISHABLE_KEY
stripe.api_key = STRIPE_SECRET_KEY

def home(request, table_id):
    table = Table.objects.get(table_id=table_id)
    #food_items = FoodItem.objects.all()
    order = Order.objects.get(table=table)
    order_items = OrderItem.objects.filter(order=order)
    subtotal = 0

    # calculate subtotal from order_items matching order number
    for order_item in order_items:
        subtotal += order_item.food_item.price * order_item.quantity

    context = {
        "table": table,
        "table_id": table_id,
        "order": order,
        "order_items_multiple": order_items,
        "subtotal":subtotal
    }
    #           original ->      'home.html'
    return render(request, "home.html", {'context':context})


def checkout(request, table_id):
    if request.method == "POST": 
        table = Table.objects.get(id=table_id)
        order = Order.objects.filter(table=table).first()
        #order_items = OrderItem.objects.filter(order=order)

        tip_str = request.POST.get('tip') # '10.00'
        subtotal_str = request.POST.get('subtotal')
        subtotal_cents = int(float(subtotal_str)*100)

        if tip_str != '-1': #percentage is chosen from drop down (tip = '0.10')
            tip_percent = float(tip_str) # '0.02'
            # calculate total_cents
            total_cents = subtotal_cents + int(subtotal_cents*tip_percent)

        else: #custom tip is chosen
            custom_tip_str_percent = request.POST.get('custom-tip') #'2'
            custom_tip_percent = float(custom_tip_str_percent)/100 # 0.02
            # calculate total_cents
            total_cents = subtotal_cents + int(subtotal_cents*custom_tip_percent)


        # Now you know the table_id, total_cents:
        # 1. Create a STRIPE PRODUCT 
        stripe_product_object = stripe.Product.create(
            name= f"Online Payment for Table {table_id}",
            description=f"Order Created at:{order.created_at}."
        )
        stripe_product_id = stripe_product_object.id #  "product": "prod_NKQoFKM8dJrI2Y",
        print(f"Stripe Product object created Successfully, id={stripe_product_id}")
        # 2. Create a STRIPE PRICE
        stripe_price_object = stripe.Price.create(
            unit_amount = total_cents,
            currency = "usd",
            product = stripe_product_id, #  "product": "prod_NKQoFKM8dJrI2Y",
        )

        # 3. GET the PRICE_ID to be used in line_items in checkout_session
        stripe_price_id = stripe_price_object.id #"id": "price_1MalCBEnT7OYNfKU2DY4Q3qP",
        print(f"Stripe Price object created Successfully, id={stripe_price_id}")

        # taken from STRIPE API guidebook (https://stripe.com/docs/checkout/quickstart)
        checkout_session = stripe.checkout.Session.create(
            payment_method_types = ['card'], 
            line_items=[
                {
                # Provide the exact Price ID (for example, pr_1234) of the product you want to sell
                'price': stripe_price_id,
                'quantity': 1,
                },  
            ],
            mode='payment',
            success_url= MY_DOMAIN + str(table_id) +'/checkout/payment_successful?checkout_session_id={CHECKOUT_SESSION_ID}',
            cancel_url= MY_DOMAIN + str(table_id) + '/checkout/payment_cancelled',
        )
        checkout_session_id = checkout_session.id
        
        print(f"Checkout Session is created!, checkout_session_id={checkout_session.id}")

        return redirect(checkout_session.url, code=303)

    ### CANNOT ACCESS /checkout, you need 
    # the checkout request did NOT come from a POST request!
    return render(request, "404.html")

##### HELPER FUNCTIONS for payment_success
# used in payment_sucess, home views to get order items in a table's order
def get_table_context(table_id):
    table = Table.objects.get(table_id=table_id)
    order = Order.objects.get(table=table)
    order_items = OrderItem.objects.filter(order=order)
    subtotal = 0
    for order_item in order_items:
        subtotal += order_item.food_item.price * order_item.quantity
    context = {
        "table_id": table_id,
        "order": order,
        "order_items": order_items,
        "subtotal": subtotal
    }
    return context # multiple OrderItems

def email_body_generator(order_items):
    email_body = ""
    # add order_items to body text
    for order_item in order_items:
        email_body+= f"\nItem: {order_item.food_item}, Quantity: {order_item.quantity}.\n"
    return email_body


# STRIPE REDIRECT SUCCESS
def payment_successful(request, table_id):
    # get table_context
    table_context = get_table_context(table_id)
    # table_context = {
    #     "table_id": table_id,
    #     "order": order,
    #     "order_items": order_items,
    #     "subtotal": subtotal
    # }

    checkout_session_id = request.GET.get("checkout_session_id")
    checkout_session_object = stripe.checkout.Session.retrieve(checkout_session_id)

    #TODO: CREATE A CUSTOMER MODEL, SAVE THE CUSTOMER INFO


    if request.method == "POST": # the email is submitted
        # checkout_session_id = request.GET.get("checkout_session_id")
        # checkout_session_object = stripe.checkout.Session.retrieve(checkout_session_id)
        
        customer_id = checkout_session_object["customer"]
        
        # retrieve the customer name and email
        customer_fullname = checkout_session_object["customer_details"]["name"]
        customer_email = checkout_session_object["customer_details"]["email"]

        #user_email = str(request.POST.get('email'))
        customer_name = customer_fullname.split(" ")[0]
        email_body = f"Dear {customer_name},\n\nThe following is a list of purchased items:\n"

        
        # using context, get email_body with order_items
        email_body += email_body_generator(table_context["order_items"])

        ### TODO: Email bodysine TOTAL'i ekle!
        total_num = checkout_session_object["amount_total"]
        total_num = total_num / 100.0

        email_body += f"\nYour payment of ${total_num} was successfully processed.\n"

        # farewell text addition
        email_body += "\nThank you for using Bertv3!\n\nHave a nice day,\nBert"
        
        email_subject = f'Table {table_id} - Receipt Copy'
        to = [customer_email]

        email = EmailMessage(email_subject, email_body, to=to)
        email.send()            
        print(f"Email sent to {customer_email}.")

        ### TODO: Delete the Order from Orders and Order Items. So that when a new customer sits at 
        # used table, a new order can be opened for that table!
        #POSTU DIREK SUCCESS OBJECTIN ALTINA AL, AUTOEMAIL GONDER, Sonrada Order ve OrdeItemlari sil!


        return render(request, "success.html", {'context':table_context})

    ### Add this order to successful orders database
    order_in_text = ""
    for order_item in table_context["order_items"]:
        order_in_text+= f"Item: {order_item.food_item}, Quantity: {order_item.quantity}.\n"

    success_object = SuccessfulOrder.objects.create(
        table_id = table_context["table_id"],
        order_in_text = order_in_text,
        checkout_session_id = checkout_session_id,
        total_amount = float(checkout_session_object["amount_total"])/100
    )
    success_object.save()

    return render(request, "success.html", {'context':table_context})


# STRIPE REDIRECT CANCELLED
def payment_cancelled(request, table_id):
    context = {
        "table_id":table_id,
    }
    return render(request, "cancelled.html", {'context':context})

### TODO:STRIPE WEBHOOK
def stripe_webhook(request):
    pass


### TODO: /WAITER 
### WAITER REGISTER/SIGNUP @/waiter/register
def waiter_register(request):
    # form is submitted
    if request.method == "POST":
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        password2 = request.POST['password2']

        if password == password2:
            # if email exists
            if User.objects.filter(email=email).exists():
                messages.info(request,'Email is already in use!')
                return redirect("waiter_register")
            # username exists
            elif User.objects.filter(username=username).exists():
                messages.info(request,'This username is already registered!')
                return redirect("waiter_register")
            else: 
                # create user
                waiter_user = User.objects.create_user(
                    username=username,
                    email=email,
                    password=password
                )
                print("Waiter User is Created.")
                ### add waiter to Waiters Group
                waiter_user.save()
                waiter_group = Group.objects.get(name='Waiters')
                waiter_group.user_set.add(waiter_user)
                print("Waiter User is Assigned to 'Waiters' Group. ")
                
                # redirect to login
                return redirect('waiter_login')
        # passwords dont match each other
        else:
            messages.info("Passwords DONT match each other!")
            return redirect("waiter_register")
        
    ## GET: first access, render register page
    else:
        return render(request, "waiter_register.html")

### WAITER LOGIN
def waiter_login(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        # authenticate user
        user = auth.authenticate(username=username, password=password)
        # if user is valid and registered
        if user is not None:
            auth.login(request, user)
            print("Waiter is AUTHENTICATED!")
            return redirect('waiter') #waiter home page
        else:
            messages.info(request, 'Credentials are NOT correct!')
            return redirect('waiter_login')
    else: 
        return render(request, "waiter_login.html")

### WAITER LOGOUT

#### WAITER HOME PAGE /waiter
@login_required
def waiter(request):
    # log in olmadiginda attigi URL
    # http://127.0.0.1:8000/accounts/login/?next=/waiter
    # "GET /accounts/login/?next=/waiter HTTP/1.1" 404 3670
    # Not Found: /accounts/login/

    ### ADD TABLE

    ### DELETE TABLE

    ### CREATE FOODITEM

    ### DELETE FOODITEM

    ### CREATE ORDER (no deletion, auto-deletes when email sent)

    ### ADD ORDERITEM

    ### DELETE ORDERITEM

    ### BUILT WITH LOVE BY CROMAGNON



    return render(request, "waiter_home.html")

