from django.contrib import admin

from checkout_app.models import *

# Register your models here.
admin.site.register(Table)
admin.site.register(FoodItem)
admin.site.register(Order)
admin.site.register(OrderItem)
admin.site.register(SuccessfulOrder)