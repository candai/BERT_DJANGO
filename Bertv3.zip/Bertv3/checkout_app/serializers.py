from rest_framework import serializers
from .models import SuccessfulOrder

class SuccessfulOrderSerializer(serializers.ModelSerializer):
    class Meta:
        model = SuccessfulOrder
        fields = (
            'table_id',
            'date_and_time',
            'order_in_text',
            'checkout_session_id',
            'total_amount',
        )
        # will be used for GET only
# http://127.0.0.1:8000/SuccOrderAPIView/