from django.db import models

class Table(models.Model):
    table_id = models.PositiveSmallIntegerField()

    def __str__(self):
        return 'Table {}'.format(self.table_id)

class FoodItem(models.Model):
    name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=6, decimal_places=2)

    def __str__(self):
        return self.name

class Order(models.Model):
    table = models.ForeignKey(Table, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return 'Table {} Order'.format(self.table_id)


class OrderItem(models.Model):
    order = models.ForeignKey(Order, on_delete=models.CASCADE)
    food_item = models.ForeignKey(FoodItem, on_delete=models.CASCADE)
    quantity = models.PositiveSmallIntegerField(default=1)

    def __str__(self):
        return '{}, Item: {}, Quantity: {}'.format(self.order.table, self.food_item ,self.quantity)

    def subtotal(self):
        return self.food_item.price * self.quantity

### REST FRAMEWORK
class SuccessfulOrder(models.Model):
    table_id = models.PositiveSmallIntegerField()
    date_and_time = models.DateTimeField(auto_now_add=True)
    order_in_text= models.TextField()
    checkout_session_id = models.TextField()
    total_amount = models.IntegerField(default=0)

    def __str__(self):
        return 'Order for table {} - {}'.format(self.table_id, self.date_and_time)
