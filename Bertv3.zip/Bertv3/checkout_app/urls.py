from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('<int:table_id>/', views.home, name='order'),
    path('<int:table_id>/checkout', views.checkout, name='checkout'),
    path('<int:table_id>/checkout/payment_successful', views.payment_successful, name='payment_successful'),
    path('<int:table_id>/checkout/payment_cancelled', views.payment_cancelled, name='payment_cancelled'),
    path('stripe_webhook', views.stripe_webhook, name='stripe_webhook'),
    path('waiter_register',views.waiter_register, name='waiter_register'),
    path('waiter_login',views.waiter_login, name='waiter_login'),
    path('waiter', views.waiter, name='waiter'),
]