from django.contrib import admin
from django.urls import path, include
from .views import SuccOrderAPIView
from rest_framework.authtoken.views import obtain_auth_token

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("checkout_app.urls")), # \checkout_app
    path('SuccOrderAPIView/', SuccOrderAPIView.as_view(), name = 'SuccOrderAPIView'), # REST API view
    path('api-auth/', include('rest_framework.urls')), # REST AUTHENTICATION
    path('api/token/', obtain_auth_token, name='obtain_auth_token') #GET API TOKEN
]
