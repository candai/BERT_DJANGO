from django.shortcuts import render
from rest_framework.views import APIView
from rest_framework.response import Response
from checkout_app.serializers import SuccessfulOrderSerializer 
from checkout_app.models import SuccessfulOrder
from rest_framework.permissions import IsAuthenticated
# AllowAny: allows any access

# # http://127.0.0.1:8000/SuccOrderAPIView/
class SuccOrderAPIView(APIView):
    ### API AUTHENTICATION
    # leave blank if you want AllowAny or comment
    # permission_classes = (IsAuthenticated,)
    # check settings.py
    
    ### GET/POST SERIALIZERS
    def get(self, request, *args, **kwargs):
        query_set = SuccessfulOrder.objects.all()
        # many=True since will return multiple Students
        serializer = SuccessfulOrderSerializer(query_set, many=True)
        # student1 = query_set.first()
        # serializer = SuccessfulOrderSerializer(student1)
        return Response(serializer.data)
    
    def post(self, request, *args, **kwargs):
        serializer = SuccessfulOrderSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors)
    #POSTMAN Postman->post->body->form-data
    # provide name and age keys with values
