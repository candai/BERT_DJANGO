function calculateTotal() {
  var subtotal = parseFloat(document.getElementById("subtotal").value);
  var tipPercentage = parseFloat(document.getElementById("tip").value);
  if (tipPercentage === -1) {
    // Custom tip selected, get the value from the input element
    tipPercentage = parseFloat(document.getElementById("custom-tip").value) * 0.01;
  }
  var total = subtotal + (subtotal * tipPercentage);
  document.getElementById("total").innerHTML = "$" + total.toFixed(2);
}

document.getElementById("tip").addEventListener("change", function() {
  var tipSelect = document.getElementById("tip");
  var customTipDiv = document.getElementById("custom-tip-div");
  if (tipSelect.value === "-1") {
    customTipDiv.style.display = "block";
    calculateTotal();
  } 
  else {
    customTipDiv.style.display = "none";
    calculateTotal();
  }
});

document.getElementById("custom-tip").addEventListener("input", function() {
  calculateTotal();
});
